package geekbrains.java_level_one.java_lesson_five;

public class Animal {

public Animal(String name){

}

public boolean run (int length){
return false;
}
public boolean swimming (int length){
return false;
}
public boolean jumpOver (int length){
return false;
}
}
